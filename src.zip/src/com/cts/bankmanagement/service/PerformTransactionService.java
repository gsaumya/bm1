package com.cts.bankmanagement.service;

import com.cts.bankmanagement.vo.TransactionVo;

public interface PerformTransactionService {
	Double updateTransactionDetail(TransactionVo transactionVo);

}
